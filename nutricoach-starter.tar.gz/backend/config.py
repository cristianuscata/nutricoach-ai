"""
Configuración central del backend. Lee .env una sola vez (lru_cache).
"""
from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # OpenAI
    openai_api_key: str

    # Tools
    tavily_api_key: str
    usda_api_key: str = "DEMO_KEY"  # USDA permite DEMO_KEY con rate limit bajo

    # Firebase
    google_application_credentials: str = "./firebase-service-account.json"
    firebase_project_id: str

    # CORS
    cors_origins: str = "http://localhost:5173"  # comma-separated

    # Logging
    log_level: str = "INFO"

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    @property
    def cors_origins_list(self) -> list[str]:
        return [o.strip() for o in self.cors_origins.split(",") if o.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
